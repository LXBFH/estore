package com.briup.dao;


import com.briup.bean.OrderLine;

public interface OrderLineDao {
	void saveOrderLine(OrderLine orderLine);
}
