package com.briup.service;

import com.briup.bean.OrderLine;

public interface IOrderLineService {
	

	void insertOrderLine(OrderLine orderLine);
}
